@component('mail::message')

    <p>{{$name}},</p>
    <p>{{$message}}</p>

@endcomponent
