<table>
    <thead>
    <tr><th>Управление образования МО Муравленко</th></tr>
    <tr><th><b>Посещаемость по школьникам</b></th></tr>
    <tr></tr>

    <tr>
        <th><b>Дата:</b></th>
        <th><?php echo e((new \DateTime())->setTimezone(new DateTimeZone('Europe/Moscow'))->format('d.m.Y H:i:s')); ?></th>
    </tr>
    <tr>
        <th><b>Пользователь:</b></th>
        <th><?php echo e(\Auth::user()['name']); ?></th>
    </tr>
    <tr></tr>

    <tr>
        <th><?php echo e($student->name); ?>, <?php echo e($student->class); ?>-<?php echo e($student->letter); ?> (<?php echo e($student->organisation); ?>)</th>
    </tr>
    <tr>
        <th width="40"></th>
        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th style="background-color: #ededed;"><?php echo e($date->format('d/m')); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td width="50"><?php echo e($association->name); ?><br><?php echo e($association->organisation); ?></td>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <?php if($result = findValue([$date->format('Y-m-d'), $association->id], ['date', 'association_id'], $attendances)): ?>
                        <?php echo e($result[0]->value); ?>

                    <?php endif; ?>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/attendance/export.blade.php ENDPATH**/ ?>