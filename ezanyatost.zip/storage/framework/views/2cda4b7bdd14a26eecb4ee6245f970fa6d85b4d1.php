<?php $__env->startSection('title', 'Добавить мероприятие'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить мероприятие</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/events" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group <?php if(!in_array(\Auth::user()->role_id, [1])): ?> form-hidden <?php endif; ?>">
            <label>Учреждение</label>
            <select name="organisation_id"
                    class="form-control form-control-block dynamic dynamic-start">
                <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organisation->id); ?>" <?php echo e((old('organisation_id') == $organisation->id ? "selected":"")); ?>>
                        <?php echo e($organisation->short_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Дата</label>
            <input type="date" name="date"
                   value="<?php echo e(old('date') ?? (new DateTime())->format('Y-m-d')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Заголовок</label>
            <input type="text" name="name"
                   value="<?php echo e(old('name')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Содержание</label>
            <textarea name="content" class="form-control form-control-block"><?php echo e(old('content')); ?></textarea>
        </div>
        <div class="form-group">
            <label>Изображение</label>
            <input name="img" type="file" class="form-control-file">
        </div>
        <button type="submit" class="btn btn-success">Добавить мероприятие</button>
    </form>
    <script src="<?php echo e(asset('js/dynamicDropdown.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/events/create.blade.php ENDPATH**/ ?>