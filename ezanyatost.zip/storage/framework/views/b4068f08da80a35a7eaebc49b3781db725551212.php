<?php $__env->startSection('title'); ?><?php echo e($organisation->short_name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($organisation->short_name); ?></h2>
    <h3>Об учреждении</h3>
    <div>
        <?php if(isset($organisation->img)): ?>
            <div class="img-wrapper">
                <a class="link-primary" target="_blank"
                   href="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                    <img src="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                </a>
            </div>
        <?php endif; ?>
        <div class="lead">
            <p>
                <b>Полное наименование:</b>
                <span><?php echo e($organisation->full_name); ?></span>
            </p>
            <p>
                <b>Краткое наименование:</b>
                <span><?php echo e($organisation->short_name); ?></span>
            </p>
            <p>
                <b>ФИО руководителя:</b>
                <span><?php echo e($organisation->director); ?></span>
            </p>
            <p>
                <b>Часы  приема:</b>
                <span><?php echo e($organisation->reception); ?></span>
            </p>
            <p>
                <b>Юридический адрес:</b>
                <span><?php echo e($organisation->legal_address); ?></span>
            </p>
            <p>
                <b>Фактический адрес:</b>
                <span><?php echo e($organisation->actual_address); ?></span>
            </p>
            <p>
                <b>Телефон:</b>
                <a class="link-primary"
                   href="tel:<?php echo e($organisation->phone); ?>"><?php echo e($organisation->phone); ?></a>
            </p>
            <?php if(isset($organisation->fax)): ?>
                <p>
                    <b>Факс:</b>
                    <span><?php echo e($organisation->fax); ?></span>
                </p>
            <?php endif; ?>
            <p>
                <b>Электронная почта:</b>
                <a class="link-primary"
                   href="mailto:<?php echo e($organisation->email); ?>"><?php echo e($organisation->email); ?></a>
            </p>
            <p>
                <b>Веб-сайт:</b>
                <a class="link-primary"
                   target="_blank"
                   href="http://<?php echo e($organisation->website); ?>"><?php echo e($organisation->website); ?></a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/organisations/show.blade.php ENDPATH**/ ?>