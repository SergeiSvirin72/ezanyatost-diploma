<?php $__env->startSection('title', 'Восстановление пароля'); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/css/opened/auth.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="auth section-padding-both">
        <img src="<?php echo e(asset('/images/logo.png')); ?>">
        <h2>Восстановление пароля</h2>
        <form method="POST" action="<?php echo e(route('password.update')); ?>">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend"><i class="fas fa-user"></i></div>
                    <input id="email"
                           type="email"
                           class="form-control"
                           name="email"
                           value="<?php echo e($email ?? old('email')); ?>"
                           placeholder="Электронная почта">

                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend"><i class="fas fa-lock"></i></div>
                    <input id="password" type="password" class="form-control" name="password"
                           placeholder="Новый пароль">
                </div>
            </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend"><i class="fas fa-lock"></i></div>
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                               placeholder="Подтверждение пароля">
                    </div>
                </div>
            <div class="form-group">
                <button type="submit" class="btn btn-outline-primary">
                    <?php echo e(__('Восстановить пароль')); ?>

                </button>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>