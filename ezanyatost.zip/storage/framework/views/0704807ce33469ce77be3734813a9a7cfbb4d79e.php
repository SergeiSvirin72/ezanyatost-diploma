<?php $__env->startSection('title'); ?><?php echo e($organisation->short_name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/css/opened/organisation.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="organisation-name section-padding-both">
        <div class="container">
            <h2><?php echo e($organisation->short_name); ?></h2>
        </div>
    </section>
    <section class="organisation-info">
        <div class="container">
            <h3>Об учреждении</h3>
            <div>
                <?php if(isset($organisation->img)): ?>
                    <div class="img-wrapper">
                        <a class="link-primary" target="_blank"
                           href="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                            <img src="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                        </a>
                    </div>
                <?php endif; ?>
                <div class="lead">
                    <p>
                        <b>Полное наименование:</b>
                        <span><?php echo e($organisation->full_name); ?></span>
                    </p>
                    <p>
                        <b>Краткое наименование:</b>
                        <span><?php echo e($organisation->short_name); ?></span>
                    </p>
                    <p>
                        <b>ФИО руководителя:</b>
                        <span><?php echo e($organisation->director); ?></span>
                    </p>
                    <p>
                        <b>Часы  приема:</b>
                        <span><?php echo e($organisation->reception); ?></span>
                    </p>
                    <p>
                        <b>Юридический адрес:</b>
                        <span><?php echo e($organisation->legal_address); ?></span>
                    </p>
                    <p>
                        <b>Фактический адрес:</b>
                        <span><?php echo e($organisation->actual_address); ?></span>
                    </p>
                    <p>
                        <b>Телефон:</b>
                        <span><?php echo e($organisation->phone); ?></span>
                    </p>
                    <?php if(isset($organisation->fax)): ?>
                        <p>
                            <b>Факс:</b>
                            <span><?php echo e($organisation->fax); ?></span>
                        </p>
                    <?php endif; ?>
                    <p>
                        <b>Электронная почта:</b>
                        <a class="link-primary"
                           href="mailto:<?php echo e($organisation->email); ?>"><?php echo e($organisation->email); ?></a>
                    </p>
                    <p>
                        <b>Веб-сайт:</b>
                        <a class="link-primary"
                           target="_blank"
                           href="http://<?php echo e($organisation->website); ?>"><?php echo e($organisation->website); ?></a>
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="organisation-table section-padding-both">
        <div class="container">
            <h2>Расписание занятий</h2>
            <form name="schedule">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="organisation" value="<?php echo e($organisation->id); ?>">
                <div class="form-group">
                    <label for="course">Выберите направление:</label>
                    <select class="form-control dynamic" name="course">
                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($course->id); ?>">
                                <?php echo e($course->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option selected disabled>Направлений пока нет</option>
                        <?php endif; ?>
                    </select>
                </div>
            </form>
            <div class="card-deck">

            </div>
        </div>
    </section>
    <script src="/js/fetchSchedule.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/organisations/show.blade.php ENDPATH**/ ?>