<?php $__env->startSection('title', 'Учреждения'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Учреждения</h1>
    <div class="form-group">
        <a href="/admin/organisations/create"
           class="btn btn-success"><i class="fas fa-plus"></i><span>Добавить учреждение</span></a>
    </div>

    <form name="fetch">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="page" value="1">
        <input type="hidden" name="column_name" value="id">
        <input type="hidden" name="sort_type" value="asc">
    </form>

    <div class="table-wrapper">
        <table class="table">
            <thead>
            <tr>
                <th data-sort_type="asc"
                    data-column_name="short_name"
                    class="sorting">Наименование <span id="short_name_icon"></span></th>
                <th></th>
                <th></th>
            </tr>
            </thead>
            <tbody>
                <?php echo $__env->make('closed.admin.organisations.index_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </tbody>
        </table>
    </div>
    <script src="<?php echo e(asset('js/fetchData.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/organisations/index.blade.php ENDPATH**/ ?>