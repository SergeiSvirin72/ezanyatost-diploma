<?php if(count($schedules)): ?>
    <?php $__currentLoopData = $weekdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card table-item">
            <div class="card-header">
                <b class="table-day"><?php echo e($weekday->name); ?></b>
            </div>
            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($schedule->day === $weekday->id): ?>
                    <div class="card-body">
                        <b class="table-time"><?php echo e((new \DateTime($schedule->start))->format('H:i')); ?> - <?php echo e((new \DateTime($schedule->end))->format('H:i')); ?></b>
                        <span class="badge badge-primary"><?php echo e($schedule->classroom); ?></span><br>
                        <span class="text"><?php echo e($schedule->association); ?></span><br>
                        <span class="text-muted"><?php echo e(formatName($schedule->teacher)); ?></span>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div>Нет предметов по этому направлению</div>
<?php endif; ?>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/organisations/schedule.blade.php ENDPATH**/ ?>