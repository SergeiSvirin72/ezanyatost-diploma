<?php $__env->startSection('title', 'Объединение - Учреждение'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Связь: Объединение - Учреждение</h1>
    <div class="form-group">
        <a href="/admin/association-organisation/create"
           class="btn btn-success"><i class="fas fa-plus"></i> Добавить связь</a>
    </div>

    <?php if(count($relationships)): ?>
        <div class="table-wrapper">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Объединение</th>
                    <th>Учреждение</th>
                    <th>Удалить</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($relationship->id); ?></td>
                        <td><?php echo e($relationship->association); ?></td>
                        <td class="td-center"><?php echo e($relationship->organisation); ?></td>
                        <td class="td-center">
                            <a href="javascript:void(0);"
                               onclick="event.preventDefault();
                                 this.nextElementSibling.submit();"
                               class="btn btn-sm btn-danger"><i class="fas fa-times"></i></a>
                            <form action="/admin/association-organisation/<?php echo e($relationship->id); ?>" method="post" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($relationships->links()); ?>

    <?php else: ?>
        <div>Связей пока нет. Добавьте новую связь.</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/activities/index.blade.php ENDPATH**/ ?>
