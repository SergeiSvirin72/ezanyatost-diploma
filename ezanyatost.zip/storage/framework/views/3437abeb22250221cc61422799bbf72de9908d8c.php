<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
    <?php else: ?>
        <li>
            <a href="#"><?php echo e(Auth::user()->name); ?></a>

            <div>
                <a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    Выйти
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/layouts/opened.blade.php ENDPATH**/ ?>
