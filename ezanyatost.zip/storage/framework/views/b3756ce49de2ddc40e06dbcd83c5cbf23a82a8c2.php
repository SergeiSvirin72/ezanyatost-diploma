<?php $__env->startSection('title', 'Добавить обучающегося'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить обучающегося</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/students">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Имя</label>
            <input type="text" name="first_name"
                   value="<?php echo e(old('first_name')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Логин</label>
            <input type="text" name="username"
                   value="<?php echo e(old('username')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Электронная почта</label>
            <input type="text" name="email"
                   value="<?php echo e(old('email')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Пароль</label>
            <input type="password" name="password"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Подтверждение пароля</label>
            <input type="password" name="password_confirmation"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Пол</label>
            <select name="gender_id" class="form-control form-control-block">
                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($gender->id); ?>" <?php echo e((old('gender_id') == $gender->id ? "selected":"")); ?>>
                        <?php echo e($gender->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Класс</label>
            <input type="text" name="class"
                   value="<?php echo e(old('class')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Буква</label>
            <input type="text" name="letter"
                   value="<?php echo e(old('letter')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group <?php if(!in_array(\Auth::user()->role_id, [1])): ?> form-hidden <?php endif; ?>"">
            <label>Учреждение</label>
            <select name="organisation_id" class="form-control form-control-block">
                <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organisation->id); ?>" <?php echo e((old('organisation_id') == $organisation->id ? "selected":"")); ?>>
                        <?php echo e($organisation->short_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Добавить обучающегося</button>
    </form>

    <div class="section-padding-top">
        <h3>Импорт из файла</h3>
        <form method="post" action="/admin/students/import" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input name="file" type="file" class="form-control-file">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-upload"></i><span>Импорт из файла</span>
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/students/create.blade.php ENDPATH**/ ?>