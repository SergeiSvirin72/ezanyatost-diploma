<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($teacher->name); ?></td>
        <td class="td-center"><?php echo e($teacher->username); ?></td>
        <td class="td-center"><?php echo e($teacher->association); ?></td>
        <td class="td-center"><?php echo e($teacher->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($teacher->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($teachers->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/teachers/index_data.blade.php ENDPATH**/ ?>