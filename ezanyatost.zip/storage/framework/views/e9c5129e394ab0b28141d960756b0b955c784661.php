<thead>
<tr>
    <th>Наименование ОДО</th>
    <th>Общее число</th>
    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($status->name); ?></th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($organisation->short_name); ?></td>
        <td class="td-center">
            <?php if($result = findValue([$organisation->id], ['organisation'], $reportAll)): ?>
                <?php echo e($result[0]->count); ?>

            <?php else: ?>
                <?php echo e('0'); ?>

            <?php endif; ?>
        </td>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="td-center">
                <?php if($result = findValue([$status->id, $organisation->id], ['status', 'organisation'], $report)): ?>
                    <?php echo e($result[0]->count); ?>

                <?php else: ?>
                    <?php echo e('0'); ?>

                <?php endif; ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/status/index_data.blade.php ENDPATH**/ ?>