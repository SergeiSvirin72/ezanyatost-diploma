<?php $__env->startSection('title'); ?> Домашнее задание <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3><?php echo e($homework->association); ?></h3>
    <p class="text-muted"><?php echo e($homework->organisation); ?></p>
    <span class="badge badge-primary"><?php echo e((new \DateTime($homework->date))->format('d.m.Y')); ?></span>
    <section class="section-padding-both">
        <div class="lead">
            <div>
                <h4>Задание:</h4>
                <p class="text"><?php echo e($homework->value); ?></p>
            </div>
        </div>
    </section>
    <?php if(count($materials)): ?>
        <div class="lead">
            <h4>Дополнительные материалы:</h4>
            <ul class="list">
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a class="link-primary"
                       target="_blank"
                       href="<?php echo e(asset('storage/'.$material->link)); ?>"><?php echo e($material->link); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/homeworks/show.blade.php ENDPATH**/ ?>