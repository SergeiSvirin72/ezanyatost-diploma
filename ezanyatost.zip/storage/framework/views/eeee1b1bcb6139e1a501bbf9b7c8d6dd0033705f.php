<thead>
<tr>
    <th>Направление</th>
    <th>Объединение</th>
    <th>Учреждение</th>
</tr>
</thead>
<tbody>
            <?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($association->course); ?></td>
                    <td><?php echo e($association->association); ?></td>
                    <td>
                        <?php if($results = findValue([$association->association], ['association'], $organisations)): ?>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($result->organisation); ?></span><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/course/index_data.blade.php ENDPATH**/ ?>