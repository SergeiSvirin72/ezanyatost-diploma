<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-img">
            <img class="card-img-top" style="object-fit: contain;"
                 src="<?php if($event->img): ?><?php echo e(asset('storage/'.$event->img)); ?><?php else: ?><?php echo e(asset('/images/noimage.png')); ?><?php endif; ?>">
        </div>
        <div class="card-body">
            <h5><a href="/events/<?php echo e($event->id); ?>" class="link-secondary"><?php echo e($event->name); ?></a></h5>
            <p class="text-muted"><?php echo e($event->organisation); ?></p>
            <span class="badge badge-primary"><?php echo e((new \DateTime($event->date))->format('d.m.Y')); ?></span>
            <p class="card-text"><?php echo e($event->content); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div style="flex-basis: 100%;"><?php echo e($events->links()); ?></div>

<?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/events/index_data.blade.php ENDPATH**/ ?>