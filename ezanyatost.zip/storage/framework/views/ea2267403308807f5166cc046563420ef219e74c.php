<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="td-ellipsis">
            <p><a href="/admin/events/<?php echo e($event->id); ?>"
               class="link-secondary"><?php echo e($event->name); ?></a></p></td>
        <td class="td-center"><?php echo e((new \DateTime($event->date))->format('d.m.Y')); ?> </td>
        <td class="td-center"><?php echo e($event->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($event->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($events->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/events/index_data.blade.php ENDPATH**/ ?>