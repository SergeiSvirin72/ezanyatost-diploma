<?php $__env->startSection('title', 'Добавить пользователя'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить пользователя</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/users">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Имя</label>
            <input type="text" name="first_name"
                   value="<?php echo e(old('first_name')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Логин</label>
            <input type="text" name="username"
                   value="<?php echo e(old('username')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Электронная почта</label>
            <input type="text" name="email"
                   value="<?php echo e(old('email')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Пароль</label>
            <input type="password" name="password"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Подтверждение пароля</label>
            <input type="password" name="password_confirmation"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Роль</label>
            <select name="role_id" class="form-control form-control-block">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e((old('role_id') == $role->id ? "selected":"")); ?>>
                        <?php echo e($role->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Добавить пользователя</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/users/create.blade.php ENDPATH**/ ?>