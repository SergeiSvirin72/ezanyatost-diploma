<table>
<thead>
<tr><th>Управление образования МО Муравленко</th></tr>
<tr><th><b>Охват дополнительным образованием по классам</b></th></tr>
<tr></tr>

<tr>
    <th><b>Дата:</b></th>
    <th><?php echo e((new \DateTime())->setTimezone(new DateTimeZone('Europe/Moscow'))->format('d.m.Y H:i:s')); ?></th>
</tr>
<tr>
    <th><b>Пользователь:</b></th>
    <th><?php echo e(\Auth::user()['name']); ?></th>
</tr>
<tr></tr>

<tr>
    <th style="background-color: #ededed;" width="50"><b>Наименование ОДО</b></th>
    <th style="background-color: #ededed;" width="15"><b>Общее число</b></th>
    <?php for($i = 1; $i < 12; $i++): ?>
        <th style="background-color: #ededed;"><b><?php echo e($i); ?> класс</b></th>
    <?php endfor; ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td ><?php echo e($organisation->short_name); ?></td>
        <td>
            <?php if($result = findValue([$organisation->id], ['organisation'], $reportAll)): ?>
                <?php echo e($result[0]->count); ?>

            <?php else: ?>
                <?php echo e('0'); ?>

            <?php endif; ?>
        </td>
        <?php for($i = 1; $i < 12; $i++): ?>
            <td>
                <?php if($result = findValue([$i, $organisation->id], ['class', 'organisation'], $report)): ?>
                    <?php echo e($result[0]->count); ?>

                <?php else: ?>
                    <?php echo e('0'); ?>

                <?php endif; ?>
            </td>
        <?php endfor; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/class/export.blade.php ENDPATH**/ ?>