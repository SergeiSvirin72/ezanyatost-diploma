<?php $__env->startSection('title', 'Восстановление пароля'); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/css/opened/auth.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="auth section-padding-both">
        <img src="<?php echo e(asset('/images/logo.png')); ?>">
        <h2>Восстановление пароля</h2>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend"><i class="fas fa-envelope"></i></div>
                    <input id="email"
                           type="text"
                           class="form-control"
                           name="email"
                           value="<?php echo e(old('email')); ?>"
                           placeholder="Электронная почта">
                </div>
            </div>

            <div class="form-group">
                    <button type="submit" class="btn btn-outline-primary">
                        <?php echo e(__('Восстановить пароль')); ?>

                    </button>
            </div>
        </form>
    </section>












































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>