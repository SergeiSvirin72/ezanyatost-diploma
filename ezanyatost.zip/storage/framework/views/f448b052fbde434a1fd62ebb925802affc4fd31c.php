<?php if(isset($all)): ?>
    <?php if($all): ?>
        <option value="">Все</option>
    <?php endif; ?>
<?php endif; ?>

<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($option->id); ?>"
        <?php echo e((old(request()->input('dependant')) == $option->id ? "selected":"")); ?>>
        <?php echo e($option->name); ?>

    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/includes/options.blade.php ENDPATH**/ ?>