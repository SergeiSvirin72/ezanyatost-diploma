<?php $__env->startSection('title', 'Учреждения'); ?>
<?php $__env->startSection('content'); ?>
    <section class="organisations section-padding-both">
        <div class="container">
            <h2>Учреждения</h2>
            <div class="card-deck">
                <?php $__empty_1 = true; $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card">
                        <div class="card-img">
                            <img class="card-img-top"
                                 src="<?php if($organisation->img): ?><?php echo e(asset('storage/'.$organisation->img)); ?><?php else: ?><?php echo e(asset('/images/noimage.jpg')); ?><?php endif; ?>">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">
                                <a href="/organisations/<?php echo e($organisation->id); ?>" class="link-secondary">
                                    <?php echo e($organisation->short_name); ?>

                                </a>
                            </h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div>Пока нет ни одного учреждения</div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/organisations/index.blade.php ENDPATH**/ ?>