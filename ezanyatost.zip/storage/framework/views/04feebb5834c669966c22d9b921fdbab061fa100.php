<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($activity->id); ?></td>
        <td><?php echo e($activity->association); ?></td>
        <td><?php echo e($activity->course); ?></td>
        <td class="td-center"><?php echo e($activity->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($activity->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($activities->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/activities/index_data.blade.php ENDPATH**/ ?>