<?php $__currentLoopData = $involvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $involvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($involvement->organisation); ?></td>
        <td class="td-center"><?php echo e($involvement->association); ?></td>
        <td class="td-center"><?php echo e(formatName($involvement->student)); ?></td>
        <td class="td-center"><?php echo e($involvement->class); ?></td>
        <td class="td-center"><?php echo e($involvement->letter); ?></td>
        <td class="td-center"><?php echo e($involvement->school); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($involvement->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($involvements->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/involvements/index_data.blade.php ENDPATH**/ ?>