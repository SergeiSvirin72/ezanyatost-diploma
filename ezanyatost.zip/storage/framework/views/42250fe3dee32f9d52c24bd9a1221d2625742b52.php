<thead>
<tr>
    <th colspan="100%" class="th-left"><?php echo e($association->name); ?> (<?php echo e($association->organisation); ?>)</th>
</tr>
<tr>
    <th></th>
    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($date->format('d.m')); ?></th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($student->name); ?></td>
        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td data-user="<?php echo e($student->id); ?>"
                data-date="<?php echo e($date->format("Y-m-d")); ?>"
                data-association="<?php echo e($association->id); ?>"
                class="td-center <?php if($date >= new DateTime('-2 week') && $date <= new DateTime('+2 week')): ?> editable <?php else: ?> td-disabled <?php endif; ?>"
            ><?php if($result = findValue([$date->format('Y-m-d'), $student->id], ['date', 'student_id'], $attendances)): ?><?php echo e($result[0]->value); ?><?php endif; ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<script src="<?php echo e(asset('js/editAttendance.js')); ?>"></script>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/attendances/index_data.blade.php ENDPATH**/ ?>