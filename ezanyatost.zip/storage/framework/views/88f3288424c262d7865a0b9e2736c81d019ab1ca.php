<table>
<thead>
<tr><th>Управление образования МО Муравленко</th></tr>
<tr><th><b>Охват дополнительным образованием по статусам</b></th></tr>
<tr></tr>

<tr>
    <th><b>Дата:</b></th>
    <th><?php echo e((new \DateTime())->setTimezone(new DateTimeZone('Europe/Moscow'))->format('d.m.Y H:i:s')); ?></th>
</tr>
<tr>
    <th><b>Пользователь:</b></th>
    <th><?php echo e(\Auth::user()['name']); ?></th>
</tr>
<tr></tr>

<tr>
    <th style="background-color: #ededed;" width="40"><b>Наименование ОДО</b></th>
    <th style="background-color: #ededed;" width="15"><b>Общее число</b></th>
    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th style="background-color: #ededed;" width="15"><b><?php echo e($status->name); ?></b></th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($organisation->short_name); ?></td>
        <td class="td-center">
            <?php if($result = findValue([$organisation->id], ['organisation'], $reportAll)): ?>
                <?php echo e($result[0]->count); ?>

            <?php else: ?>
                <?php echo e('0'); ?>

            <?php endif; ?>
        </td>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="td-center">
                <?php if($result = findValue([$status->id, $organisation->id], ['status', 'organisation'], $report)): ?>
                    <?php echo e($result[0]->count); ?>

                <?php else: ?>
                    <?php echo e('0'); ?>

                <?php endif; ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/status/export.blade.php ENDPATH**/ ?>