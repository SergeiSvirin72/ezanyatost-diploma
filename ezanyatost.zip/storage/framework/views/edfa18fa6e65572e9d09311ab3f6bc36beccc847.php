<?php $__env->startSection('title'); ?><?php echo e($event->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($event->name); ?></h2>
    <div>
        <?php if(isset($event->img)): ?>
            <div class="img-wrapper">
                <a class="link-primary" target="_blank"
                   href="<?php echo e(asset('storage/'.$event->img)); ?>">
                    <img src="<?php echo e(asset('storage/'.$event->img)); ?>">
                </a>
            </div>
        <?php endif; ?>
            <p class="text-muted"><?php echo e($event->organisation); ?></p>
            <span class="badge badge-primary"><?php echo e((new \DateTime($event->date))->format('d.m.Y')); ?></span>
            <p class="text"><?php echo e($event->content); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/events/show.blade.php ENDPATH**/ ?>