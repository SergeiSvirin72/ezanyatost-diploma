<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <title>E-Занятость - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('/images/favicon.ico')); ?>" type="image/x-icon">
    <link href="<?php echo e(asset('/css/opened/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/opened/header.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/opened/footer.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
<!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
        (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
            m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
        (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

        ym(64456888, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true
        });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/64456888" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
</head>
<body>
    <div class="wrapper">
        <header class="header-wrapper">
            <div class="container header">
                <div class="header-logo">
                    <img src="<?php echo e(asset('/images/logo.png')); ?>">
                </div>
                <div class="header-bars">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="header-navigation">
                    <nav>
                        <ul>
                            <li><a href="/" class="link-secondary">Главная</a></li>
                            <li><a href="/organisations" class="link-secondary">Учреждения</a></li>
                            <li><a href="/events" class="link-secondary">Мероприятия</a></li>
                            <li><a href="/contacts" class="link-secondary">Контакты</a></li>
                            <li><a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary"><i class="fas fa-user"></i> Личный кабинет</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer class="footer">
            <section class="container footer-upper">
                <div class="footer-nav">
                    <h5>Навигация</h5>
                    <a href="/" class="link-primary">Главная</a>
                    <a href="/organisations" class="link-primary">Учреждения</a>
                    <a href="/events" class="link-primary">Мероприятия</a>
                    <a href="/contacts" class="link-primary">Контакты</a>
                    <a href="<?php echo e(route('login')); ?>" class="link-primary">Личный кабинет</a>
                </div>
                <div class="footer-info">
                    <h5>Правовая информация</h5>
                    <a href="" class="link-primary">Лицензионное соглашение</a>
                    <a href="" class="link-primary">Политика обработки персональных данных</a>
                    <a href="" class="link-primary">Авторские права</a>
                </div>
                <div class="footer-gototop">
                    <a href="javascript:void(0);" class="link-primary">Наверх <i class="fas fa-angle-up"></i></a>
                </div>
            </section>
            <section class="container footer-lower">
                <p>Свирин Сергей. Московский Политехнический Университет.</p>
            </section>
        </footer>
    </div>
</body>
<script src="<?php echo e(asset('js/scrollToTop.js')); ?>"></script>
<script src="<?php echo e(asset('js/responsiveNav.js')); ?>"></script>
</html>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/layouts/opened.blade.php ENDPATH**/ ?>