<?php $__env->startSection('title', 'Расписание'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Расписание</h1>
    <div class="table-wrapper">
        <table class="table table-lg table-scroll table-valign">
            <thead>
            <tr><th class="th-left" colspan="3"><?php echo e($student->name); ?>, <?php echo e($student->class); ?>-<?php echo e($student->letter); ?> (<?php echo e($student->organisation); ?>)</th></tr>
            <tr>
                <th>Наименование ОДО</th>
                <th>Объединение</th>
                <th>Время занятий</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($association->organisation); ?></td>
                    <td><?php echo e($association->association); ?></td>
                    <td>
                        <?php if($results = findValue([$association->id], ['association'], $schedules)): ?>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e(substr($result->start, 0, 5)); ?> - <?php echo e(substr($result->end, 0, 5)); ?> <?php echo e($result->weekday); ?></span><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3">Обучающийся не вовлечен во внеурочную деятельность</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/involvement/index.blade.php ENDPATH**/ ?>