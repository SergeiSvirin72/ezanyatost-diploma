<?php $__env->startSection('title', 'Личный кабинет'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Личный кабинет</h1>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <section class="section-padding-bottom">
        <div class="lead">
            <p><b>Ф.И.О: </b><span> <?php echo e(\Auth::user()->name); ?></span></p>
            <p><b>Роль: </b><span> <?php echo e($role); ?></span></p>
            <?php switch(\Auth::user()->role_id):
                case (2): ?>
                    <p><b>Учреждение: </b><span> <?php echo e($info->organisation); ?></span></p>
                <?php break; ?>

                <?php case (3): ?>
                    <p><b>Учреждение: </b><span> <?php echo e($info->organisation); ?></span></p>
                    <p><b>Объединение: </b><span> <?php echo e($info->association); ?></span></p>
                <?php break; ?>

                <?php case (5): ?>
                    <p><b>Пол: </b><span> <?php echo e($info->gender); ?></span></p>
                    <p><b>Учреждение: </b><span> <?php echo e($info->organisation); ?></span></p>
                    <p><b>Класс: </b><span> <?php echo e($info->class); ?><?php echo e($info->letter); ?></span></p>
                    <p><b>Статус: </b>
                        <?php $__empty_1 = true; $__currentLoopData = $info->statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span><?php echo e($status); ?><?php if(!$loop->last): ?>,<?php endif; ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span>Нет</span>
                        <?php endif; ?>
                    </p>
                <?php break; ?>
            <?php endswitch; ?>
        </div>
    </section>
    <section class="home-form">
        <h3>Добавить электронную почту</h3>
        <form method="POST" action="/home/email">
            <?php if($errors->first('email')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('email')); ?>

                </div>
            <?php endif; ?>
                <?php if(session('success_email')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success_email')); ?>

                    </div>
                <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="email"
                       value="<?php echo e(old('email', \Auth::user()['email'])); ?>"
                       class="form-control form-control-block"
                        placeholder="Электронная почта">
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-outline-primary" value="Добавить">
            </div>
        </form>
    </section>
    <section class="home-form">
        <h3>Изменить пароль</h3>
        <form method="POST" action="/home/password">
            <?php if($errors->first('password') || $errors->first('password_confirmation')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('password') ? $errors->first('password') : $errors->first('password_confirmation')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('success_password')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success_password')); ?>

                </div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="password" name="password" class="form-control form-control-block"
                       placeholder="Пароль">
            </div>
            <div class="form-group">
                <input type="password" name="password_confirmation" class="form-control form-control-block"
                       placeholder="Подтверждение пароля">
            </div>
            <div class="form-group">
                <button type="submit" name="auth_submit" class="btn btn-outline-primary">Изменить</button>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/index.blade.php ENDPATH**/ ?>