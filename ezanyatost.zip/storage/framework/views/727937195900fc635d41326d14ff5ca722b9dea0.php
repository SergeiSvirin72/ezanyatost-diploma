<?php $__env->startSection('title'); ?><?php echo e($event->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/css/opened/event.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="event section-padding-both">
        <div class="container">
            <h2><?php echo e($event->name); ?></h2>
            <?php if(isset($event->img)): ?>
                <div class="img-wrapper event-img">
                    <a class="link-primary" target="_blank"
                       href="<?php echo e(asset('storage/'.$event->img)); ?>">
                        <img src="<?php echo e(asset('storage/'.$event->img)); ?>">
                    </a>
                </div>
            <?php endif; ?>
            <p class="text-muted"><?php echo e($event->organisation); ?></p>
            <span class="badge badge-primary"><?php echo e((new \DateTime($event->date))->format('d.m.Y')); ?></span>
            <p class="text text-pre"><?php echo e($event->content); ?></p>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/events/show.blade.php ENDPATH**/ ?>