<?php $__env->startSection('title', 'Традиционные мероприятия'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Традиционные мероприятия</h1>
    <form name="fetch" method="post">
        <input type="hidden" name="header">
        <div class="form-group">
            <label>Учреждение</label>
            <select name="organisation_id"
                    class="form-control form-control-block dynamic dynamic-start">
                <?php if($all): ?>
                    <option value="">Все</option>
                <?php endif; ?>
                <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organisation->id); ?>" <?php echo e((old('organisation_id') == $organisation->id ? "selected":"")); ?>>
                        <?php echo e($organisation->short_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group form-group-row">
            <input type="date" name="start"
                   value="<?php echo e((new DateTime())->modify('-7 day')->format('Y-m-d')); ?>"
                   class="form-control form-control-block">
            <input type="date" name="end"
                   value="<?php echo e((new DateTime())->modify('+7 day')->format('Y-m-d')); ?>"
                   class="form-control form-control-block" style="margin-left: 8px">
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-search"></i><span>Найти</span>
            </button>
        </div>
        <input type="hidden" id="dynamic-fetch" value="/report/event/fetch">
        <?php echo csrf_field(); ?>
    </form>

    <div class="table-wrapper">
        <table class="table table-lg table-scroll">
        </table>
    </div>
    <script src="<?php echo e(asset('js/dynamicDropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fetchData.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/event/index.blade.php ENDPATH**/ ?>