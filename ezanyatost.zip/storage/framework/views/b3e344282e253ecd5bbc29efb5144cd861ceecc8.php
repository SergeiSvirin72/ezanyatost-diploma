<?php $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="td-pre td-ellipsis"><p><a href="/admin/homeworks/<?php echo e($homework->id); ?>"
                                             class="link-secondary"><?php echo e($homework->homework); ?></a></p></td>
        <td class="td-center"><?php echo e((new \DateTime($homework->date))->format('d.m.Y')); ?></td>
        <td class="td-center"><?php echo e($homework->association); ?></td>
        <td class="td-center"><?php echo e($homework->organisation); ?> </td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($homework->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($homeworks->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/homeworks/index_data.blade.php ENDPATH**/ ?>