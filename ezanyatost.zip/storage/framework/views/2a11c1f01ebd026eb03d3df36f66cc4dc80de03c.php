<table>
<thead>
<tr><th>Управление образования МО Муравленко</th></tr>
<tr><th><b>Перечень направлений внеурочной деятельности</b></th></tr>
<tr></tr>

<tr>
    <th><b>Дата:</b></th>
    <th><?php echo e((new \DateTime())->setTimezone(new DateTimeZone('Europe/Moscow'))->format('d.m.Y H:i:s')); ?></th>
</tr>
<tr>
    <th><b>Пользователь:</b></th>
    <th><?php echo e(\Auth::user()['name']); ?></th>
</tr>
<tr></tr>

<tr>
    <th style="background-color: #ededed;" width="40"><b>Направление</b></th>
    <th style="background-color: #ededed;" width="40"><b>Объединение</b></th>
    <th style="background-color: #ededed;" width="40"><b>Учреждение</b></th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($association->course); ?></td>
        <td><?php echo e($association->association); ?></td>
        <td width="50">
            <?php if($results = findValue([$association->association], ['association'], $organisations)): ?>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($result->organisation); ?>

                    <?php if(!$loop->last): ?>
                        <br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/course/export.blade.php ENDPATH**/ ?>