<?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <a href="/admin/organisations/<?php echo e($organisation->id); ?>"
               class="link-secondary"><?php echo e($organisation->short_name); ?></a>
        </td>
        <td class="td-center">
            <a href="/admin/organisations/<?php echo e($organisation->id); ?>/edit"
               class="btn btn-sm btn-primary"><i class="fas fa-pen"></i></a>
        </td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($organisation->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($organisations->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/organisations/index_data.blade.php ENDPATH**/ ?>