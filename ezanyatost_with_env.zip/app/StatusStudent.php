<?php

namespace App;

use Illuminate\Database\Eloquent\Relations\Pivot;

class StatusStudent extends Pivot
{
    //
}
