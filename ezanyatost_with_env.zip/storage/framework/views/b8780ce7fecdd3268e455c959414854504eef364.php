<?php $__env->startSection('title', 'Добавить расписание'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить расписание</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/schedules">
        <?php echo csrf_field(); ?>
        <div class="form-group <?php if(!in_array(\Auth::user()->role_id, [1])): ?> form-hidden <?php endif; ?>">
            <label>Учреждение</label>
            <select name="organisation_id"
                    class="form-control form-control-block dynamic dynamic-start"
                    data-dependant="associations">
                <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organisation->id); ?>" <?php echo e((old('organisation_id') == $organisation->id ? "selected":"")); ?>>
                        <?php echo e($organisation->short_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Объединение</label>
            <select id="associations"
                    name="association_id"
                    class="form-control form-control-block dynamic"
                    data-dependant="teachers">
            </select>
        </div>
        <div class="form-group">
            <label>Преподаватель</label>
            <select id="teachers"
                    name="teacher_id" class="form-control form-control-block dynamic-end">
            </select>
        </div>
        <div class="form-group">
            <label>День недели</label>
            <select name="weekday_id" class="form-control form-control-block">
                <?php $__currentLoopData = $weekdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($weekday->id); ?>" <?php echo e((old('weekday_id') == $weekday->id ? "selected":"")); ?>>
                        <?php echo e($weekday->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>Время начала</label>
            <input type="time" name="start"
                   value="<?php echo e(old('start') ?? '00:00'); ?>"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Время окончания</label>
            <input type="time" name="end"
                   value="<?php echo e(old('start') ?? '00:00'); ?>"
                   class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Учебная аудитория</label>
            <input type="text" name="classroom"
                   value="<?php echo e(old('classroom')); ?>" class="form-control form-control-block">
        </div>
        <button type="submit" class="btn btn-success">Добавить расписание</button>
    </form>

    <div class="section-padding-top">
        <h3>Импорт из файла</h3>
        <form method="post" action="/admin/schedules/import" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input name="file" type="file" class="form-control-file">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-upload"></i><span>Импорт из файла</span>
                </button>
            </div>
        </form>
    </div>
    <script src="<?php echo e(asset('js/dynamicDropdown.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/schedules/create.blade.php ENDPATH**/ ?>