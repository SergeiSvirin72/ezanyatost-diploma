<?php $__env->startSection('title', 'Добавить учреждение'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить учреждение</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/organisations" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Полное наименование</label>
            <input type="text" name="full_name"
                   value="<?php echo e(old('full_name')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Краткое наименование</label>
            <input type="text" name="short_name"
                   value="<?php echo e(old('short_name')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Директор</label>
            <select name="director_id" class="form-control form-control-block">
                <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($director->id); ?>" <?php echo e((old('director_id') == $director->id ? "selected":"")); ?>>
                        <?php echo e($director->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Часы приема</label>
            <input type="text" name="reception"
                   value="<?php echo e(old('reception')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Юридический адрес</label>
            <input type="text" name="legal_address"
                   value="<?php echo e(old('legal_address')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Фактический адрес</label>
            <input type="text" name="actual_address"
                   value="<?php echo e(old('actual_address')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone"
                   value="<?php echo e(old('phone')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Факс</label>
            <input type="text" name="fax"
                   value="<?php echo e(old('fax')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Электронная почта</label>
            <input type="text" name="email"
                   value="<?php echo e(old('email')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Веб-сайт</label>
            <input type="text" name="website"
                   value="<?php echo e(old('website')); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <input type="checkbox" name="is_school" <?php echo e(old('is_school') ? 'checked' : ''); ?>>
            <label class="form-check-label">Это школа?</label>
        </div>
        <div class="form-group">
            <label>Изображение</label>
            <input name="img" type="file" class="form-control-file">
        </div>

        <button type="submit" class="btn btn-success">Добавить учреждение</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/organisations/create.blade.php ENDPATH**/ ?>