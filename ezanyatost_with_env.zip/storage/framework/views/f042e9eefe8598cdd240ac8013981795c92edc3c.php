<?php $__env->startSection('title', 'Добавить связь'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавить связь: Преподаватель - Занятие</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/employments">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Учреждение</label>
            <select name="organisation_id"
                    class="form-control form-control-block dynamic"
                    data-dependant="associations, teachers">
                <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organisation->id); ?>">
                        <?php echo e($organisation->short_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Преподаватель</label>
            <select id="teachers"
                name="teacher_id" class="form-control form-control-block">
            </select>
        </div>
        <div class="form-group">
            <label>Объединение</label>
            <select id="associations"
                name="association_id" class="form-control form-control-block">
            </select>
        </div>
        <button type="submit" class="btn btn-success">Добавить связь</button>
    </form>
    <script src="<?php echo e(asset('js/dynamicDropdown.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/employments/create.blade.php ENDPATH**/ ?>