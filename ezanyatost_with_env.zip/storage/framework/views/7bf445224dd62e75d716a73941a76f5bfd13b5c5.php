<thead>
<tr>
    <th>Наименование ОДО</th>
    <th>Общее число</th>
    <?php for($i = 1; $i < 12; $i++): ?>
        <th><?php echo e($i); ?> класс</th>
    <?php endfor; ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($organisation->short_name); ?></td>
        <td class="td-center">
            <?php if($result = findValue([$organisation->id], ['organisation'], $reportAll)): ?>
                <?php echo e($result[0]->count); ?>

            <?php else: ?>
                <?php echo e('0'); ?>

            <?php endif; ?>
        </td>
        <?php for($i = 1; $i < 12; $i++): ?>
            <td class="td-center">
                <?php if($result = findValue([$i, $organisation->id], ['class', 'organisation'], $report)): ?>
                    <?php echo e($result[0]->count); ?>

                <?php else: ?>
                    <?php echo e('0'); ?>

                <?php endif; ?>
            </td>
        <?php endfor; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/class/index_data.blade.php ENDPATH**/ ?>