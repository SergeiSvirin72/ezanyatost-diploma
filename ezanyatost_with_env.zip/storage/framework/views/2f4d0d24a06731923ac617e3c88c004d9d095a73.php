<thead>
<tr>
    <th colspan="100%" class="th-left"><?php echo e($student->name); ?>, <?php echo e($student->class); ?>-<?php echo e($student->letter); ?> (<?php echo e($student->organisation); ?>)</th>
</tr>
<tr>
    <th></th>
    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <th><?php echo e($date->format('d.m')); ?></th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($association->name); ?><br><?php echo e($association->organisation); ?></td>
        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="td-center">
                <?php if($result = findValue([$date->format('Y-m-d'), $association->id], ['date', 'association_id'], $attendances)): ?>
                    <?php echo e($result[0]->value); ?>

                <?php endif; ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<script src="<?php echo e(asset('js/editAttendance.js')); ?>"></script>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/attendance/index_data.blade.php ENDPATH**/ ?>