<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->name); ?></td>
        <td class="td-center"><?php echo e($user->username); ?></td>
        <td class="td-center"><?php echo e($user->role); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($user->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($users->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/users/index_data.blade.php ENDPATH**/ ?>