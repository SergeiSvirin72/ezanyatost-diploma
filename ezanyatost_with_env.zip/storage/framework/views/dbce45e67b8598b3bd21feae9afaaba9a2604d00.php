<?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($association->name); ?></td>
        <td class="td-center"><?php echo e($association->course); ?></td>
        <td class="td-center"><?php echo e($association->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($association->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($associations->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/associations/index_data.blade.php ENDPATH**/ ?>