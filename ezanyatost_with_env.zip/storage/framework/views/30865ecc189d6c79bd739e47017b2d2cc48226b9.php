<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($student->name); ?></td>
        <td class="td-center"><?php echo e($student->username); ?></td>
        <td class="td-center"><?php echo e($student->gender); ?></td>
        <td class="td-center"><?php echo e($student->class); ?></td>
        <td class="td-center"><?php echo e($student->letter); ?></td>
        <td class="td-center"><?php echo e($student->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($student->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($students->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/students/index_data.blade.php ENDPATH**/ ?>