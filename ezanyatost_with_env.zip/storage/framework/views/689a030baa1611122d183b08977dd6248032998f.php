<?php $__env->startSection('title', 'Редактировать учреждение'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Редактировать учреждение</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/admin/organisations/<?php echo e($organisation->id); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="form-group">
            <label>Полное наименование</label>
            <input type="text" name="full_name"
                   value="<?php echo e($organisation->full_name); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Краткое наименование</label>
            <input type="text" name="short_name"
                   value="<?php echo e($organisation->short_name); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Директор</label>
            <select name="director_id" class="form-control form-control-block">
                <option value="">Выберите директора</option>
                <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($director->id); ?>"
                        <?php echo e(($organisation->director_id == $director->id ? "selected":"")); ?>>
                        <?php echo e($director->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label>Часы приема</label>
            <input type="text" name="reception"
                   value="<?php echo e($organisation->reception); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Юридический адрес</label>
            <input type="text" name="legal_address"
                   value="<?php echo e($organisation->legal_address); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Фактический адрес</label>
            <input type="text" name="actual_address"
                   value="<?php echo e($organisation->actual_address); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone"
                   value="<?php echo e($organisation->phone); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Факс</label>
            <input type="text" name="fax"
                   value="<?php echo e($organisation->fax); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Электронная почта</label>
            <input type="text" name="email"
                   value="<?php echo e($organisation->email); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <label>Веб-сайт</label>
            <input type="text" name="website"
                   value="<?php echo e($organisation->website); ?>" class="form-control form-control-block">
        </div>
        <div class="form-group">
            <input type="checkbox" name="is_school"
                   <?php if($organisation->is_school): ?> checked <?php endif; ?>>
            <label class="form-check-label">Это школа?</label>
        </div>
        <?php if(isset($organisation->img)): ?>
            <div class="img-wrapper">
                <a class="link-primary" target="_blank"
                   href="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                    <img src="<?php echo e(asset('storage/'.$organisation->img)); ?>">
                </a>
            </div>
        <?php endif; ?>
        <div class="form-group">
            <label>Изображение</label><br>
            <input name="img" type="file" class="form-control-file">
            <a href="/admin/organisations/<?php echo e($organisation->id); ?>/delete_image" class="btn btn-danger">
                <i class="fas fa-times"></i>
                <span>Удалить изображение</span>
            </a>
        </div>

        <button type="submit" class="btn btn-success">Редактировать учреждение</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/organisations/edit.blade.php ENDPATH**/ ?>