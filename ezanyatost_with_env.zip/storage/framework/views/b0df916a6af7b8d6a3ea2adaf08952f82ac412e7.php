<?php $__env->startSection('title', 'Домашние задания'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Домашние задания</h1>
    <form name="fetch">
        <input type="hidden" name="header">
        <input type="hidden" id="dynamic-fetch" class="dynamic-start" value="/report/homework/student/fetch">
        <?php echo csrf_field(); ?>
    </form>
    <div class="table-wrapper">
        <table class="table table-lg table-scroll">

        </table>
    </div>
    <script src="<?php echo e(asset('js/dynamicDropdown.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.closed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/homework/student.blade.php ENDPATH**/ ?>