<?php $__env->startSection('title', 'Авторизация'); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/css/opened/auth.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="auth section-padding-both">
        <img src="<?php echo e(asset('/images/logo.png')); ?>">
        <h2>Авторизация</h2>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend"><i class="fas fa-user"></i></div>
                    <input type="text"
                           name="username"
                           value="<?php echo e(old('username')); ?>"
                           class="form-control"
                           placeholder="Логин">
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend"><i class="fas fa-lock"></i></div>
                    <input type="password" name="password" class="form-control" placeholder="Пароль">
                </div>
            </div>




            <div class="form-group">
                <button type="submit" name="auth_submit" class="btn btn-outline-primary">Войти</button>
            </div>
            <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>" class="link-primary">Забыли пароль?</a>
            <?php endif; ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/auth/login.blade.php ENDPATH**/ ?>