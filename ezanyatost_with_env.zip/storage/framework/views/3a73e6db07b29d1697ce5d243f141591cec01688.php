<?php $__env->startSection('title', 'Учреждения'); ?>
<?php $__env->startSection('content'); ?>
    <section class="events section-padding-both">
        <div class="container">
            <h2>Мероприятия</h2>
            <form name="fetch">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="page" value="1">
                <div class="form-group">
                    Выберите учреждение:
                    <select name="organisation"
                            class="form-control form-control-block dynamic dynamic-start">
                        <?php if($all): ?>
                            <option value="">Все</option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $organisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($organisation->id); ?>" <?php echo e((old('organisation_id') == $organisation->id ? "selected":"")); ?>>
                                <?php echo e($organisation->short_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
            <div class="card-deck">

            </div>
        </div>
    </section>
    <script src="/js/fetchEvents.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.opened', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\ezanyatost_v2\resources\views/opened/events/index.blade.php ENDPATH**/ ?>