

<?php $__currentLoopData = $involvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $involvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <pre>
        <?php echo e($involvement->association); ?>

        <?php echo e($involvement->student); ?>

        <?php if($results = findValue([$involvement->association], ['association'], $weekDays)): ?>
            <?php
                $start = (new \DateTime())->modify('-7 day');
                $end = (new \DateTime())->modify('+7 day');
                $weekDays_prep = [];
                foreach ($results as $result) {
                    //if($result->weekday == 7) $result->weekday = 0;
                    $weekDays_prep[] = $result->weekday;
                }
                print_r($start);
                print_r($end);
                print_r($weekDays_prep);
                print_r(generateDates($start, $end, $weekDays_prep));
            ?>
            <?php echo e(print_r($weekDays_prep)); ?>

        <?php endif; ?>
    </pre>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/test.blade.php ENDPATH**/ ?>