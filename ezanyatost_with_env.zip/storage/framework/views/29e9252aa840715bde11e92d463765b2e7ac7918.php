<?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($schedule->association); ?></td>
        <td class="td-center"><?php echo e($schedule->weekday); ?></td>
        <td class="td-center"><?php echo e((new \DateTime($schedule->start))->format('H:i')); ?></td>
        <td class="td-center"><?php echo e((new \DateTime($schedule->end))->format('H:i')); ?></td>
        <td class="td-center"><?php echo e($schedule->classroom); ?></td>
        <td class="td-center"><?php echo e(formatName($schedule->teacher)); ?></td>
        <td class="td-center"><?php echo e($schedule->organisation); ?></td>
        <td class="td-center">
            <a href="javascript:void(0);"
               class="btn btn-sm btn-danger delete"
               data="<?php echo e($schedule->id); ?>"><i class="fas fa-times"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><td class="td-pagination"><?php echo e($schedules->links()); ?></td></tr>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/admin/schedules/index_data.blade.php ENDPATH**/ ?>