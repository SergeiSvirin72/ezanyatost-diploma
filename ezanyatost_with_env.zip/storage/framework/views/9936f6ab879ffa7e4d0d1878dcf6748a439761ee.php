<thead>
<tr><th colspan="4" class="th-left"><?php echo e($student->name); ?>, <?php echo e($student->class); ?>-<?php echo e($student->letter); ?> (<?php echo e($student->organisation); ?>)</th></tr>
<tr>
    <th>Наименование ООО</th>
    <th>Объединение</th>
    <th>Дата</th>
    <th>Задание</th>
</tr>
</thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <tr <?php if(new \DateTime($homework->date) <= (new \DateTime())->modify('-1 day')): ?> class="tr-disabled" <?php endif; ?>>
        <td><?php echo e($homework->organisation); ?></td>
        <td><?php echo e($homework->association); ?></td>
        <td><?php echo e((new \DateTime($homework->date))->format('d.m.Y')); ?></td>
        <td class="td-pre td-ellipsis"><p><a href="/report/homework/student/<?php echo e($homework->id); ?>"
                                             class="link-secondary"><?php echo e($homework->value); ?></a></p></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="4">Нет домашних заданий</td></tr>
<?php endif; ?>
</tbody>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/homework/student_data.blade.php ENDPATH**/ ?>