<thead>
<tr>
    <th>Учреждение</th>
    <th>Дата</th>
    <th>Мероприятие</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($event->organisation); ?></td>
        <td><?php echo e((new \DateTime($event->date))->format('d.m.Y')); ?></td>
        <td class="td-ellipsis">
            <p><a href=/events/<?php echo e($event->id); ?>"
                  class="link-secondary"><?php echo e($event->name); ?></a></p></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH W:\domains\ezanyatost_v2\resources\views/closed/reports/event/index_data.blade.php ENDPATH**/ ?>